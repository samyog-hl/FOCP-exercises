name = input("enter your name:")
if name =="":
    print("Hello stranger")
else:
    print("hello",name)
