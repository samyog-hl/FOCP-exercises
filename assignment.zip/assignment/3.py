''' Modify your previous program so that the password must be between 8 and 12
 characters (inclusive) long.'''
new_password =input("enter your new password:")
if len(new_password) < 8 or len(new_password) >12:
    print("password must be between 8 and 12 characters long.")
else:
    conform_password = input("enter your conform password:")
    if new_password == conform_password:
        print("password set Successfully.")
    else:
        print("password do not match !error")
