'''Modify your program again so that the chosen password cannot be one of a list of
 common passwords, defined thus:
 BAD_PASSWORDS = ['password', 'letmein', 'sesame', 'hello', 'justinbieber']'''

bad_password = ['password', 'letmein', 'sesame', 'hello', 'justinbieber']
new_password =input("enter your new password:")
if len(new_password) < 8 or len(new_password) >12:              #check password length is valid or not
    print("password must be between 8 and 12 characters long.")
elif new_password in bad_password:
    print("this password is common choose different one.")       #check if password is too common
else:
    conform_password = input("enter your conform password:")
    if new_password == conform_password:
        print("password set Successfully.")
    else:
        print("password do not match !error")
