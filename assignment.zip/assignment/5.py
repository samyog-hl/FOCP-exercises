'''Modify your program a final time so that it executes until the user successfully
 chooses a password. That is, if the password chosen fails any of the checks, the
 program should return to asking for the password the first time.'''
bad_password = ['password', 'letmein', 'sesame', 'hello', 'justinbieber']

while True:
    new_password = input("enter a new password:")

    if len(new_password) < 8 or len(new_password) > 12:
        print("Error: Password must be between 8 and 12 characters long.")
        continue
    if new_password .lower() in bad_password:
        print("this password is common choose different one.")
    confirm_password = input("Enter your Confirm password: ")

    if new_password != confirm_password:
        print("Error: Passwords do not match.")
        continue
    
    print("Password Set Successfully!")
    break
