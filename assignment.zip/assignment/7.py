''' Modify your "Times Table" program so that the user enters the number of the table
 they require. This number should be between 0 and 12 inclusive. '''

num = int(input("enter a number:"))
if num < 0 or num > 12:
    print("Error: Please enter a number between 0 and 12.")
else:
    for i in range(num):
        print(i, "x 7 =", i * 7)
