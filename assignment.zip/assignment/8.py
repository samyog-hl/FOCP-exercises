''' Modify the "Times Table" again so that the user still enters the number of the table,
 but if this number is negative the table is printed backwards. So entering "-7"
would produce the Seven Times Table starting at "12 times" down to "0 times". '''


num = int(input("Enter a number for the times table (use negative to print backwards): "))

if abs(num) >12:       # Check if the absolute value is within 0–12
      print("Error: Please enter a number between -12 and 12.")
else:
     abs_num = abs(num)
    
     if num >= 0:
        for i in range(13):                      # Forward table
            print(i, "x", abs_num, "=", i * abs_num)
     else:                                         # Backward table
        for i in range(12, -1, -1):
            print(i, "x", abs_num, "=", i * abs_num)
